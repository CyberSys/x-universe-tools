X2 TXT Editor readme - updated 6.6.2005

CONTENTS:
=========
1.  REQUIEREMENTS
1.1 SYSTEM REQUIEREMENTS
1.2 GAME REQUIEREMENTS
2.  CREDITS

WARRANTY:
=========

This program is provided 'as is' without any warranty. If you manage to break 
your game with it, it's all your fault. If you do not accept this, then do not
use this software!

1. REQUIEREMENTS:
=================

1.1 SYSTEM REQUIEREMENTS:
-------------------------
This program is written in Microsoft Visual Basic 6.0 and needs Visual Basic 
runtime libraries.
If you have Microsoft Visual Studio 6.0 or higher then you probably have them.
The installer will check if you have them and download and install them if 
neccessary.
You can also download them manually from
http://www.doubleshadow.wz.cz - section Downloads

1.2 GAME REQUIEREMENTS:
-----------------------
Since version 0.0.20 there are no longer any requirements.
You DON'T need to have you game files unpacked (for 0.0.20 and greater!).

2. CREDITS:
===========
Author: Doubleshadow (doubleshadow@volny.cz, http://www.doubleshadow.wz.cz)

PCK and CAT decoding algorithms
-------------------------------
Thanks to Laga Mahessa aka Stone-D for providing me part of his ASM source 
codes.

TXT Editor
----------
Thanks to: Shadowtech and Storm_Front for their info about txt files structure.

Galaxy Editor
-------------
Thanks to: AalaarDB for his post "Manually Editing the Galaxy Using a Text 
           Editor" on Egosoft forum (this inspired me to do the GE).

Also thanks to Kryptyk and DeadlyDa for their beta testing.
