X2 ModManager readme - updated 7.3.2005

CONTENTS:
=========
1.  SYSTEM REQUIEREMENTS
2.  CREDITS

WARRANTY:
=========

This program is provided 'as is' without any warranty. If you manage to break 
your game with it, it's all your fault. If you do not accept this, then do not
use this software!

1 SYSTEM REQUIEREMENTS:
=======================
X2 ModManager requires Visual Basic 6 runtime libraries, Visual C Runtime 
Library (msvcr71.dll) and zlib (zlib1.dll) library.

These files will be downloaded and installed automatically if they are not 
present on your system, or they can be downloaded from 
http://www.doubleshadow.wz.cz

2 CREDITS:
==========
Author: Doubleshadow  - doubleshadow@volny.cz
                        http://www.doubleshadow.wz.cz
                        
PCK and CAT decoding algorithms
-------------------------------
Thanks to Laga Mahessa aka Stone-D for providing me part of his assembler 
source codes.